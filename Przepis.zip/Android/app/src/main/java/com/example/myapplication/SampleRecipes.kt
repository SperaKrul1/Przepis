/*
package com.example.myapplication

val sampleRecipes = listOf(
    Recipe(
        title = "Spaghetti Bolognese",
        description = "Makaron z mięsem i sosem pomidorowym.",
        ingredients = "Makaron, mięso mielone, pomidory",
        imageUrl = null,
        category = "obiad",
        isCustom = true
    ),
    Recipe(
        title = "Kurczak curry",
        description = "Aromatyczny kurczak w sosie curry.",
        ingredients = "Kurczak, mleko kokosowe, przyprawy",
        imageUrl = null,
        category = "obiad",
        isCustom = true
    )
)
*/