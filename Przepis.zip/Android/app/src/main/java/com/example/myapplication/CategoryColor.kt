/*
package com.example.myapplication.utils

import androidx.compose.ui.graphics.Color

fun getCategoryColor(category: String): Color {
    return when(category.lowercase()) {
        "śniadanie", "breakfast" -> Color.Green
        "obiad", "lunch", "dinner" -> Color.Red
        "kolacja", "supper" -> Color.Blue
        else -> Color.Gray
    }
}
*/